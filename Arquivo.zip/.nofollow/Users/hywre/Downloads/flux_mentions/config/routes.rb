# Plugin's routes
# See: http://guides.rubyonrails.org/routing.html
# resources :usercomplete do
#     collection do
#       get 'users'
#     end
#   end
#   match '/users/auto_complete', :to => 'auto_complete#users', :via => :get, :as => 'auto_complete_users'

