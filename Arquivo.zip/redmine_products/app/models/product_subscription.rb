# This file is a part of Redmine Products (redmine_products) plugin,
# customer relationship management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_products is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_products is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_products.  If not, see <http://www.gnu.org/licenses/>.

# frozen_string_literal: true

class ProductSubscription < ApplicationRecord
  include Redmine::SafeAttributes

  belongs_to :author, class_name: 'User'
  belongs_to :project
  has_one :product_line

  scope :visible, lambda { |*args| joins(:project, :product_line).where(Project.allowed_to_condition(args.first || User.current, :view_subscriptions)) }
  scope :live_search, lambda { |search| where("(LOWER(#{ProductSubscription.table_name}.reference_id) LIKE LOWER(:p))", { p: "%#{search.downcase}%"}) }

  acts_as_customizable
  acts_as_event datetime: :created_at,
                url: Proc.new { |o| { controller: 'product_subscriptions', action: 'show', project_id: o.project_id, id: o.id } },
                type: 'icon icon-bookmarked-project',
                title: Proc.new { |o| o.reference_id },
                description: Proc.new { |o| [o.reference_id, o.product_line.try(&:container)].join(' - ') }

  acts_as_activity_provider type: 'product_subscriptions',
                            permission: :view_subscriptions,
                            timestamp: "#{table_name}.created_at",
                            author_key: :author_id,
                            scope: joins(:project)

  validates :reference_id, :start_date, :expire_date, :author_id, presence: true, allow_blank: false
  validate :product_line_uniqless, on: :create
  validate :subscription_dates, on: [:create, :update]

  safe_attributes 'reference_id',
                  'start_date',
                  'expire_date',
                  'author_id',
                  'custom_field_values'

  def product_line_uniqless
    return unless product_line

    if ProductLine.where(id: product_line.id).first.try(:product_subscription_id)
      errors.add(:product_subscription, l(:error_product_subscription_already_exists))
    end
  end

  def subscription_dates
    return unless errors.empty?

    errors.add(:product_subscription, l(:error_product_subscription_expire_before_start)) if expire_date < start_date
  end

  def fullname
    [reference_id, product_line.title].compact.join(' - ')
  end

  def expired?
    expire_date < DateTime.now
  end
end
