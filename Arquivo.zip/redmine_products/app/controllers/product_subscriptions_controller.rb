# This file is a part of Redmine Products (redmine_products) plugin,
# customer relationship management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_products is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_products is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_products.  If not, see <http://www.gnu.org/licenses/>.

class ProductSubscriptionsController < ApplicationController
  before_action :find_optional_project
  before_action :build_production_subscription, only: [:new, :create]
  before_action :find_product_subscription, :only => [:show, :edit, :update]
  before_action :authorize

  helper :products
  helper :sort
  helper :crm_queries
  helper :queries
  helper :custom_fields
  include SortHelper
  include ProductsHelper
  include QueriesHelper
  include CrmQueriesHelper

  def index
    retrieve_crm_query('product_subscription')
    sort_init(@query.sort_criteria.empty? ? [['expire_date', 'asc']] : @query.sort_criteria)
    sort_update(@query.sortable_columns)
    @query.sort_criteria = sort_criteria.to_a

    if @query.valid?
      @limit = per_page_option
      @product_subscriptions_count = @query.object_count
      @product_subscriptions_scope = @query.objects_scope
      @product_subscriptions_pages = Paginator.new @product_subscriptions_count, @limit, params['page']
      @offset ||= @product_subscriptions_pages.offset
      @product_subscription_count_by_group = @query.object_count_by_group
      @product_subscriptions = @query.results_scope(
        :search => params[:search],
        :order => sort_clause,
        :limit  =>  @limit,
        :offset =>  @offset
      )

      respond_to do |format|
        format.html { render partial: 'list_excerpt', layout: false if request.xhr? }
      end
    else
      respond_to do |format|
        format.html { render(:template => 'product_subscriptions/index', :layout => !request.xhr?) }
        format.any(:atom, :csv, :pdf) { render(:nothing => true) }
      end
    end
  rescue ActiveRecord::RecordNotFound
    render_404
  end

  def new
    @product_subscription.start_date = Date.today
  end

  def show
    redirect_to subscription_container_path(@product_subscription)
  end

  def edit
  end

  def create
    if @product_subscription.save
      flash.now[:notice] = l(:notice_successful_create)
      respond_to do |format|
        format.js
      end
    else
      respond_to do |format|
        format.js { render action: 'new' }
      end
    end
  end

  def update
    @product_subscription.safe_attributes = params[:product_subscription]
    if @product_subscription.save
      flash.now[:notice] = l(:notice_successful_update)
      respond_to do |format|
        format.js
      end
    else
      respond_to do |format|
        format.js { render action: 'edit' }
      end
    end
  end

  def destroy
    product_subscription = @project.product_subscriptions.find(params[:id])
    if product_subscription.destroy
      flash[:notice] = l(:notice_successful_delete)
      @field_id = params[:field_id]
    else
      flash[:error] = l(:notice_unsuccessful_delete)
    end
    respond_to do |format|
      format.js { render action: 'update' }
    end
  end

  private

  def build_production_subscription
    @product_subscription = @project.product_subscriptions.build
    @product_subscription.safe_attributes = params[:product_subscription]
    @product_subscription.product_line = find_product_line
    @product_subscription.author = User.current

    @field_id = find_field_id unless @product_subscription.product_line
  end

  def find_product_line
    ProductLine.where(id: params[:product_line_id] || params[:product_subscription].try(:[], :product_line_id)).first
  end

  def find_field_id
    params[:field_id] || params[:product_subscription].try(:[], :field_id)
  end

  def find_product_subscription
    @product_subscription = @project.product_subscriptions.includes(:product_line).find(params[:id])
  rescue ActiveRecord::RecordNotFound
    render_404
  end
end
