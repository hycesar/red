# This file is a part of Redmine Products (redmine_products) plugin,
# customer relationship management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_products is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_products is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_products.  If not, see <http://www.gnu.org/licenses/>.

require_dependency 'auto_completes_controller'

module RedmineProducts
  module Patches
    module AutoCompletesControllerPatch
      def self.included(base)
        base.send(:include, InstanceMethods)

        base.class_eval do
          helper :products
          include ProductsHelper
          include ActionView::Helpers::TagHelper
          include ActionView::Helpers::AssetTagHelper
        end
      end

      module InstanceMethods
        def products
          @products = []
          q = (params[:q] || params[:term]).to_s.strip
          scope = Product.visible.active
          scope = scope.includes(:image).limit(params[:limit] || 10)
          scope = scope.live_search(q) unless q.blank?
          @products = scope.order("#{Product.table_name}.name")
          render json: formatted_products(@products)
        end

        def orders
          @orders = []
          q = (params[:q] || params[:term]).to_s.strip
          scope = Order.visible
          scope = scope.limit(params[:limit] || 10)
          scope = scope.where(:currency => params[:currency]) if params[:currency]
          scope = scope.where(:status_id => params[:status_id]) if params[:status_id]
          scope = scope.live_search(q) unless q.blank?
          @orders = scope.order("#{Order.table_name}.number")
          render json: formatted_orders(@orders)
        end

        private

        def formatted_products(products)
          products.map do |product|
            {
              'id' => product.id,
              'code' => product.code,
              'info' => "#{product_image_tag(product, :size => 16)} #{product.code} - #{product.name}#{' (' + product.price_to_s + ')' unless product.price.blank?}".html_safe,
              'name' => product.name,
              'image' => product_image_tag(product, :size => 16).html_safe,
              'avatar' => product_image_tag(product, :size => 16).html_safe,
              'price' => product.price_to_s,
              'currency' => product.currency,
              'value' => product.code,
              'text' => product.name
            }
          end
        end

        def formatted_orders(orders)
          orders.map do |order|
            {
              'id' => order.id,
              'label' => order.to_s,
              'number' => order.number,
              'name' => order.to_s,
              'amount' => order.amount_to_s,
              'currency' => order.currency,
              'value' => order.id,
              'text' => order.to_s
            }
          end
        end
      end
    end
  end
end

unless AutoCompletesController.included_modules.include?(RedmineProducts::Patches::AutoCompletesControllerPatch)
  AutoCompletesController.send(:include, RedmineProducts::Patches::AutoCompletesControllerPatch)
end
