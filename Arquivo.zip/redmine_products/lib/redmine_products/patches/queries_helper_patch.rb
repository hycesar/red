# This file is a part of Redmine Products (redmine_products) plugin,
# customer relationship management plugin for Redmine
#
# Copyright (C) 2011-2025 RedmineUP
# http://www.redmineup.com/
#
# redmine_products is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# redmine_products is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with redmine_products.  If not, see <http://www.gnu.org/licenses/>.

require_dependency 'queries_helper'

module RedmineProducts
  module Patches
    module QueriesHelperPatch
      def self.included(base)
        base.send(:include, InstanceMethods)

        base.class_eval do
          alias_method :column_value_without_products, :column_value
          alias_method :column_value, :column_value_with_products

          alias_method :csv_value_without_products, :csv_value
          alias_method :csv_value, :csv_value_with_products
        end
      end

      module InstanceMethods
        def column_value_with_products(column, list_object, value)
          if [:order_number, :order_subject].include?(column.name) && list_object.is_a?(Order)
            link_to(h(value), order_path(list_object))
          elsif column.name == :order_amount && list_object.is_a?(Order)
            list_object.amount_to_s
          elsif column.name == :price && list_object.is_a?(Product)
            list_object.price_to_s
          elsif column.name == :id && list_object.is_a?(Product)
            link_to(h(value), product_path(list_object))
          elsif [:code, :name].include?(column.name) && list_object.is_a?(Product)
            link_to(h(value), product_path(list_object))
          elsif value.is_a?(Order)
            order_tag(value)
          elsif value.is_a?(Product)
            product_tag(value, :no_contact => true, :plain => true, :size => 16)
          elsif column.name == :tags && list_object.is_a?(Product)
            product_tag_links(value.map(&:name))
          elsif column.name == :products
            products_span = []
            value.each do |product|
              products_span << product_tag(product)
            end
            products_span.join(', ').html_safe
          else
            column_value_without_products(column, list_object, value)
          end
        end

        def csv_value_with_products(column, object, value)
          if column.name == :products
            value.to_a.map(&:to_s).join(', ')
          else
            csv_value_without_products(column, object, value)
          end
        end
      end
    end
  end
end

unless QueriesHelper.included_modules.include?(RedmineProducts::Patches::QueriesHelperPatch)
  QueriesHelper.send(:include, RedmineProducts::Patches::QueriesHelperPatch)
end
