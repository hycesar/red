# Load the Redmine helper
require File.expand_path(File.dirname(__FILE__) + '/../../../test/test_helper')

class RedmineFavoriteProjects::TestCase

  def self.create_fixtures(fixtures_directory, table_names, class_names = {})
    ActiveRecord::FixtureSet.create_fixtures(fixtures_directory, table_names, class_names = {})
  end
end

def compatible_request(type, action, parameters = {})
  headers = parameters.delete(:headers) || {}
  @request.headers.merge!(headers)
  @request.env.merge!(headers)
  send(type, action, params: parameters)
end

def compatible_xhr_request(type, action, parameters = {})
  send(type, action, params: parameters, xhr: true)
end
