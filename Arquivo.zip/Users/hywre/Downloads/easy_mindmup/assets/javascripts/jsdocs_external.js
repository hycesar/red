/**
 * Created by hosekp on 11/14/16.
 */
(function () {
  /**
   * Do not include this file - it is just for suppressing JSDocs warnings
   */
  window.showModal =function(){};
  jQuery.fn.dialog=function(){};
  /**
   *
   * @param {String} type
   * @param {String} message
   * @param {number} delay
   */
  window.showFlashMessage=function(type, message, delay){};
  /**
   *
   * @param {String} htmlId
   */
  window.fillFormTextAreaFromCKEditor = function(htmlId){};

  jQuery.Deferred.prototype.done = function (func) {

  };
  window._ = window._ || {};
});
