# Easy WBS

For documentation and requirements, go to https://www.easyredmine.com/redmine-wbs-plugin
